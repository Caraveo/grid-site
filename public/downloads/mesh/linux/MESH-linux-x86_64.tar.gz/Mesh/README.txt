Mesh for Linux
==============
1. chmod +x mesh
2. ./mesh
Opens the Mesh UI locally (grid:// browser shell).
