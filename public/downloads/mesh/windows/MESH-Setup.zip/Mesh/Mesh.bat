@echo off
setlocal
set PORT=17420
cd /d "%~dp0app"
echo Mesh · http://127.0.0.1:%PORT%
start "" "http://127.0.0.1:%PORT%/"
where py >nul 2>&1 && (
  py -3 -m http.server %PORT% --bind 127.0.0.1
  goto :eof
)
where python >nul 2>&1 && (
  python -m http.server %PORT% --bind 127.0.0.1
  goto :eof
)
echo Install Python 3 or open app\index.html in Microsoft Edge.
pause
