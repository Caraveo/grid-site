Mesh for Windows 11+
====================
Double-click Mesh.bat
Uses local UI shell. Edge/Chrome recommended.
